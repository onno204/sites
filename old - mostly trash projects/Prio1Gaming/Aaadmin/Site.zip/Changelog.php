<?php
require 'Utils.php';
$Utils = new Utils();
$Utils->ConnectCheck();


$Utils->LastLoad();