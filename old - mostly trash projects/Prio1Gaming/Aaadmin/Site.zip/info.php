<?php
echo "<br>Max upload Side: " . ini_get("upload_max_filesize");
echo "<br>Max upload Side: " . ini_get("upload_max_filesize");
echo "<br>Post Max upload Side: " . ini_get("post_max_size");
phpinfo();