<?php


return (object) array(
    'MainPath' => 'http://Program.onno204.nl.eu.org/',
    'MainPathRaw' => $_SERVER['DOCUMENT_ROOT'] . "/",
    'RootSite' => "http://Program.onno204.nl.eu.org/",
    'ServerTitle' => 'onno204 Site',
    'DBIp' => 'localhost',
    'username' => 'onno204n_Program',
    'pass' => 'Program123',
    'database' => 'onno204n_Program'
);


?>